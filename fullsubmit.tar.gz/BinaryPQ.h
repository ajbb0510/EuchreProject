#ifndef BINARYPQ_H
#define BINARYPQ_H


#include <algorithm>
#include "Eecs281PQ.h"

// A specialized version of the priority queue ADT implemented as a binary heap.
template<typename TYPE, typename COMP = std::less<TYPE>>
class BinaryPQ : public Eecs281PQ<TYPE, COMP> {
    using base = Eecs281PQ<TYPE, COMP>;

public:
    // Description: Construct an empty heap with an optional comparison functor.
    // Runtime: O(1)
    BinaryPQ(COMP comp = COMP()) :
        base{ comp } {
        // TODO: Remove the logic_error exception and implement this function!
        throw std::logic_error("Not implemented!");
    } // BinaryPQ


    // Description: Construct a heap out of an iterator range with an optional
    //              comparison functor.
    // Runtime: O(n) where n is number of elements in range.
    template<typename InputIterator>
    BinaryPQ(InputIterator start, InputIterator end, COMP comp = COMP()) :
        base{ comp } {
        // TODO: Remove the logic_error exception and implement this function!
        throw std::logic_error(((void)start, (void)end, "Not implemented!"));
    } // BinaryPQ


    // Description: Destructor doesn't need any code, the data vector will
    //              be destroyed automaticslly.
    virtual ~BinaryPQ() {
    } // ~BinaryPQ()


    // Description: Assumes that all elements inside the heap are out of order and
    //              'rebuilds' the heap by fixing the heap invariant.
    // Runtime: O(n)
    virtual void updatePriorities() {
        // TODO: Remove the logic_error exception and implement this function!
        throw std::logic_error("Not implemented!");
    } // updatePriorities()


    // Description: Add a new element to the heap.
    // Runtime: O(log(n))
    virtual void push(const TYPE & val) {
        // TODO: Remove the logic_error exception and implement this function!
        throw std::logic_error(((void)val, "Not implemented!"));
    } // push()


    // Description: Remove the most extreme (defined by 'compare') element from
    //              the heap.
    // Note: We will not run tests on your code that would require it to pop an
    // element when the heap is empty. Though you are welcome to if you are
    // familiar with them, you do not need to use exceptions in this project.
    // Runtime: O(log(n))
    virtual void pop() {
        // TODO: Remove the logic_error exception and implement this function!
        throw std::logic_error("Not implemented!");
    } // pop()


    // Description: Return the most extreme (defined by 'compare') element of
    //              the heap.
    // Runtime: O(1)
    virtual const TYPE & top() const {
        // TODO: Remove the logic_error exception and implement this function!
        throw std::logic_error("Not implemented!");
    } // top()


    // Description: Get the number of elements in the heap.
    // Runtime: O(1)
    virtual std::size_t size() const {
        // TODO: Remove the logic_error exception and implement this function!
        // NOTE: This function might be very simple, depending on your implementation.
        throw std::logic_error("Not implemented!");
    } // size()


    // Description: Return true if the heap is empty.
    // Runtime: O(1)
    virtual bool empty() const {
        // TODO: Remove the logic_error exception and implement this function!
        // NOTE: This function might be very simple, depending on your implementation.
        throw std::logic_error("Not implemented!");
    } // empty()


private:
    // Note: This vector *must* be used your heap implementation.
    std::vector<TYPE> data;

    //TODO: Add any additional member functions or data you require here.

}; // BinaryPQ


#endif // BINARYPQ_H
